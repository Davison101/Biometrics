import cv2, face_recognition as fr, os, numpy as np

def encode(folder):
    encs, names = [], []
    for person in os.listdir(folder):
        for img in os.listdir(f"{folder}/{person}"):
            path = f"{folder}/{person}/{img}"
            if img.lower().endswith(('jpg','jpeg','png')):
                try:
                    face = fr.face_encodings(fr.load_image_file(path))
                    if face: encs.append(face[0]); names.append(person)
                except: pass
    return encs, names

def authenticate(encs, names, threshold=0.6):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened(): print("No camera"); return
    print("Show face. Press 'q' to quit.")
    
    while True:
        ret, frame = cap.read()
        if not ret: break
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        locs = fr.face_locations(rgb)
        enc = fr.face_encodings(rgb, locs)
        
        for e in enc:
            dists = fr.face_distance(encs, e)
            i = np.argmin(dists)
            name = names[i] if dists[i] < threshold else "Unknown"
            cv2.putText(frame, f"{name} ({dists[i]:.2f})", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)

        cv2.imshow("Auth", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'): break

    cap.release(); cv2.destroyAllWindows()

# Run
known_encs, known_names = encode("images")
authenticate(known_encs, known_names)
